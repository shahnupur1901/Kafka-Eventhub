import java.util.Collections;
import java.util.concurrent.CompletableFuture;
import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
public class AADClientCred {
    public static void main(String[] args) {
        String tenantID = "611bd08b-538f-4eba-a6c7-d4dbc6060ed4";
        String clientID = "72f988bf-86f1-41af-91ab-2d7cd011db47";
        String Secret = "Qzs8Q~VmhJDKs6EcKI8Vie0PFI9RDZhD1UnJbc_C";
        String authority = "https://login.windows-ppe.net/" + tenantID;
        //I use microsoft graph as resource for demo
        String scope = "https://eventhubs.azure.net/.default";
        try {
            String access_token = getAccessTokenByClientCredentialGrant(clientID, Secret, authority, scope)
                    .accessToken();
            System.out.println("access token : " + access_token);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static IAuthenticationResult getAccessTokenByClientCredentialGrant(String clientID, String Secret,
                                                                               String authority, String scope) throws Exception {
        ConfidentialClientApplication app = ConfidentialClientApplication
                .builder(clientID, ClientCredentialFactory.createFromSecret(Secret)).authority(authority).build();
        ClientCredentialParameters clientCredentialParam = ClientCredentialParameters
                .builder(Collections.singleton(scope)).build();
        CompletableFuture<IAuthenticationResult> future = app.acquireToken(clientCredentialParam);
        return future.get();
    }
}