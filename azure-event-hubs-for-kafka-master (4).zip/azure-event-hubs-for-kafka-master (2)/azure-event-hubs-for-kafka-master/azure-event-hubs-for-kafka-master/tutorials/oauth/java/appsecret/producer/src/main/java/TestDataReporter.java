//Copyright (c) Microsoft Corporation. All rights reserved.
//Licensed under the MIT License.
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.util.concurrent.TimeUnit;

public class TestDataReporter implements Runnable {

    private static final int NUM_MESSAGES = 10000000;
    private final String TOPIC;

    private Producer<Long, String> producer;

    public TestDataReporter(final Producer<Long, String> producer, String TOPIC) {
        this.producer = producer;
        this.TOPIC = TOPIC;
    }

    @Override
    public void run() {
        for(int i = 0; i < NUM_MESSAGES; i++) {
            try {
                TimeUnit.SECONDS.sleep(20);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            long time = System.currentTimeMillis();
            int n = 1000;
            System.out.println("Test Data #" + i + " from thread #" + Thread.currentThread().getId() + " of size " + n*16 + " bytes");

            final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(TOPIC, time, GetStringOfLargeSize(n));
            producer.send(record, new Callback() {
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    if (exception != null) {
                        System.out.println(exception);
                        System.exit(1);
                    }
                    else
                    {
                        System.out.println(metadata.toString());
                        System.out.println(metadata.serializedKeySize() + " " + metadata.serializedValueSize());
                    }

                }
            });
        }
        System.out.println("Finished sending " + NUM_MESSAGES + " messages from thread #" + Thread.currentThread().getId() + "!");
    }

    private String GetStringOfLargeSize(int n)
    {
        String str = "Event 1000000000";
        String finalStr = "";
        for (int i = 0; i < n; i++)
        {
            finalStr = finalStr + str;
        }
        return finalStr;
    }
}